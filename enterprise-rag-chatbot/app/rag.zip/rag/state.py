from typing import TypedDict, List


class GraphState(TypedDict):

    question: str

    context: str

    answer: str

    