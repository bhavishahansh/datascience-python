from langchain_community.vectorstores import FAISS

def create_vector_store(embedding_model):

    def save_vector_store(chunks, embedding_model):

        vector_db = FAISS.from_documents(
            chunks,
            embedding_model
        )

        vector_db.save_local("data/vectorstore")

        return vector_db

    return FAISS.load_local(
        "data/vectorstore",
        embedding_model,
        allow_dangerous_deserialization=True
    )

