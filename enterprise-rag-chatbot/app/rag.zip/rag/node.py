from langchain_core.output_parsers import StrOutputParser
from app.rag.prompt import RAG_PROMPT


def retrieve_node(state, retriever):

    docs = retriever.invoke(state["question"])

    context = "\n\n".join(
        doc.page_content
        for doc in docs
    )

    state["context"] = context

    return state


def generate_node(state, llm):

    chain = (
        RAG_PROMPT
        | llm
        | StrOutputParser()
    )

    answer = chain.invoke(
        {
            "context": state["context"],
            "question": state["question"]
        }
    )

    state["answer"] = answer

    return state